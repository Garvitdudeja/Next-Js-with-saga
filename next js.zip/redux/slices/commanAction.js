import { createAction } from "@reduxjs/toolkit";

export const restAllData = createAction("RESET_ALL");
