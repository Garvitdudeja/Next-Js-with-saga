import companyLogo from "../public/images/logo.svg";

export { companyLogo };
