// import { PulseLoader } from "react-spinners";

// const PageLoader = () => {
//   return (
//     <div className="page-loader-outer">
//       <PulseLoader color="#1B75BC" />
//     </div>
//   );
// };

// export default PageLoader;
