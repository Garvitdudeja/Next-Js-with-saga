// import Card from "react-bootstrap/Card";
// import Col from "react-bootstrap/Col";
// import Row from "react-bootstrap/Row";

// function BoxCard() {
//   const boxCardData = [
//     {
//       title: "SportsDS",

//     },
//     {
//       title: "RetailDS",
     
//     },
//     {
//       title: "OperationsDS",
    
//     },
//   ]
//   return (
//     <Row xs={1} md={2} lg={3} className="g-4 item_center boxCardmain mt-2 mt-lg-3">
//       {boxCardData.map((item, index) => (
//         <Col key={index}>
//           <Card className="boxCard">
//             <div className="d-flex justify-content-between">
//               <h5>{item.title}</h5>
//               <img
//                 className="BoxcardImg"
//                 src="./images/card-img.svg"
//                 alt="card-image"
//               />
//             </div>
//             <div className="boxArrow"></div>
//           </Card>
//         </Col>
//       ))}
//     </Row>
//   );
// }

// export default BoxCard;
