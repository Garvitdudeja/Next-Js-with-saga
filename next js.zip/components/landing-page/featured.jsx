const Featured = () => {
  return <div>Featured</div>;
};

export default Featured;
