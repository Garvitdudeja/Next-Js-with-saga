const HowWorks = () => {
  return <div>HowWorks</div>;
};

export default HowWorks;
