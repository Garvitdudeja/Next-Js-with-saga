const Questions = () => {
  return <div>Questions</div>;
};

export default Questions;
