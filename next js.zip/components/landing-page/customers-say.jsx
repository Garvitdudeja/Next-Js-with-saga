const CustomersSay = () => {
  return <div>CustomersSay</div>;
};

export default CustomersSay;
