import React from "react";

const WhyLabas = () => {
  return <div>WhyLabas</div>;
};

export default WhyLabas;
