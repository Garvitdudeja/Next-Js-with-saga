import BlogsPage from '@/components/latestBlogs/blogsPage'
import React from 'react'

const Blogs = () => {
  return (
    <div>
        <BlogsPage/>
    </div>
  )
}

export default Blogs