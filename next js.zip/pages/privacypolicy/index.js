import CookiePolicyPage from '@/components/cookiePolicy'
import PrivacyPolicyPage from '@/components/privacyPolicyPage'
import React from 'react'

const PrivacyPolicy = () => {
  return (
    <div><PrivacyPolicyPage /></div>
  )
}

export default PrivacyPolicy