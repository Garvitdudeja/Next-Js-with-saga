import BlogsDetailPage from '@/components/latestBlogs/blogsDetailPage'
import React from 'react'

const BlogDetails = () => {
  return (
    <div><BlogsDetailPage /></div>
  )
}

export default BlogDetails