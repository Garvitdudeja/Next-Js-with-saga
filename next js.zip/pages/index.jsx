import LandingPage from "@/components/landing-page";
// import YourPrivacyCard from "@/components/yourPrivacyCard";


const HomePage = () => {
 
  return (
    <>
        <LandingPage />
        {/* <YourPrivacyCard/> */}
    </>
  );
};

export default HomePage;
