import TermsAndConditionPage from '@/components/termsAndCondition'
import React from 'react'

const TermsAndCondition = () => {
  return (
    <div><TermsAndConditionPage /></div>
  )
}

export default TermsAndCondition