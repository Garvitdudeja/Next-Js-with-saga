import CookiePolicyPage from '@/components/cookiePolicy'
import React from 'react'

const CookiePolicy = () => {
  return (
    <div><CookiePolicyPage /></div>
  )
}

export default CookiePolicy